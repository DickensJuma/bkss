<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CallendarController extends Controller
{
    public function index(){

    }
    public function create(){

    }
    public function store(){
        
    }
}
