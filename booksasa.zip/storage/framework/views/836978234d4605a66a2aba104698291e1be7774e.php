

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center">List your property on Book sasa and start welcoming guests in no time!!</h3>
        <p>To get started select the type of property you want to list</p>
        <div class="rows">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-success">Apartment</h4>
                    </div>
                    <div class="card-body">
                        <p>Furnished and self-catering accomodation where quests rent the entire place</p>
                    </div>
                    <div class="card-footer">
                        <a href="" class="btn btn-secondary">List your property</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-success">Apartment</h4>
                    </div>
                    <div class="card-body">
                        <p>Furnished and self-catering accomodation where quests rent the entire place</p>
                    </div>
                    <div class="card-footer">
                        <a href="" class="btn btn-secondary">List your property</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-success">Apartment</h4>
                    </div>
                    <div class="card-body">
                        <p>Furnished and self-catering accomodation where quests rent the entire place</p>
                    </div>
                    <div class="card-footer">
                        <a href="" class="btn btn-secondary">List your property</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-success">Apartment</h4>
                    </div>
                    <div class="card-body">
                        <p>Furnished and self-catering accomodation where quests rent the entire place</p>
                    </div>
                    <div class="card-footer">
                        <a href="" class="btn btn-secondary">List your property</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Zulu\booksasa\resources\views/property/new.blade.php ENDPATH**/ ?>