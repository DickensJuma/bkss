
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        VAT/Tax/Charges
                    <sup class="text-danger"><small>new</small></sup>
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('adminhome')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Properties</li>
                    <li class="breadcrumb-item active">Tax Charges</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
        </section>
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-haeder">
                                    <div class="alert alert-warning alert-block" id="autoClose" >
                                        <button type="button" class="close" data-dismiss="alert">×</button>	
                                        <em class="text-light">Your VAT and Taxation charges are as follows. Note that you can update only the Service charge rate while the rest are calculated automatically.
                                            <br>Incase the ratea are incorrect, please feel free to contact us.
                                        </em>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Now</th>
                                                <th>Most Popular In<?php echo e($property_city); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $levies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $levy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($levy->name); ?></td>
                                                <td><?php echo e($levy->percentage); ?>%</td>
                                            </tr>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php $__currentLoopData = $levies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $levy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </section>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Work\booksasa\resources\views/property/levy.blade.php ENDPATH**/ ?>