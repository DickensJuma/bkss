

<?php $__env->startSection('content'); ?>

<?php echo $hotel; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Zulu\booksasa\resources\views/search.blade.php ENDPATH**/ ?>