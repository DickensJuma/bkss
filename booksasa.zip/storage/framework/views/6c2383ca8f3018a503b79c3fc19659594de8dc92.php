<!-- header start -->
<div class="header-classic">
            <!-- navigation start -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <nav class="navbar navbar-expand-lg navbar-classic">
                            <a class="navbar-brand" href="index.html"> <img src="<?php echo e(asset('front/assets/images/logo.png')); ?>" alt=""></a>
                            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbar-classic" aria-controls="navbar-classic" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar top-bar mt-0"></span>
                                <span class="icon-bar middle-bar"></span>
                                <span class="icon-bar bottom-bar"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbar-classic">
                                <ul class="navbar-nav ml-auto mt-2 mt-lg-0 mr-3">
                                    <li class="nav-item ">
                                        <a class="nav-link" href="index.html">
                                            Stays
                                        </a>                                        
                                    </li>
                                    <li class="nav-item ">
                                        <a class="nav-link" href="index.html">
                                            Travel
                                        </a>                                        
                                    </li>
                                    <li class="nav-item ">
                                        <a class="nav-link" href="index.html">
                                            Rentals
                                        </a>                                        
                                    </li>
                                    <li class="nav-item ">
                                        <a class="nav-link" href="index.html">
                                            Office Space
                                        </a>                                        
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="menu-4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            My Account </a>
                                        <ul class="dropdown-menu" aria-labelledby="menu-4">
                                        <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <li class="dropdown-item">
                                                <a class="dropdown-link" href="<?php echo e(url('/home')); ?>">
                                                   Home</a>
                                            </li>
                                             <?php else: ?>
                                            <li class="dropdown-item">
                                                <a class="dropdown-link" href="<?php echo e(route('login')); ?>">
                                                    Login</a>
                                            </li>
                                            <?php if(Route::has('register')): ?>
                                            <li class="dropdown-item">
                                                <a class="dropdown-link" href="<?php echo e(route('register')); ?>">
                                                    Register</a>
                                            </li>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </ul>
                                    </li>                                 
                                </ul>
                                <div class="header-btn">
                                    <a href="<?php echo e(route('property.add')); ?>" class="btn btn-primary">List Your Property</a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- navigation close -->
        </div>
        <!-- header close --><?php /**PATH F:\Work\booksasa\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>