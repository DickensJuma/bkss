

<?php $__env->startSection('content'); ?>
<div class='container'>

<?php echo $hotel_data; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Zulu\booksasa\resources\views/room/view.blade.php ENDPATH**/ ?>