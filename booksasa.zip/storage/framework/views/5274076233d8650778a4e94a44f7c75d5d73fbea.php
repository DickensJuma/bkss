<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="Rentkit a design system for real estate, office space and realtor.">
        <title>Homepage - Rentkit a design system for real estate, office space and realtor.</title>
        <link rel="shortcut icon" href="<?php echo e(asset('front/assets/images/favicon.ico')); ?>" type="image/x-icon"> 
        <!-- Bootstrap CSS -->    
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/theme.min.css')); ?>">
    </head>
    <body>
        <div class="main-wrapper">
             <?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--page content section-->
            <?php echo $__env->yieldContent('content'); ?>
            <!--footer section-->
            <?php echo $__env->make('layouts.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper -->
        <!-- ============================================================== -->
        <!-- Libs JS -->
        <script src="<?php echo e(asset('front/assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('front/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('front/assets/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
        <script src="<?php echo e(asset('front/assets/libs/select2/dist/js/select2.min.js')); ?>"></script>         
        <script src="<?php echo e(asset('front/assets/libs/moment/min/moment.min.js')); ?>"></script>    
        <script src="<?php echo e(asset('front/assets/libs/lightpick/lightpick.js')); ?>"></script> 
        <!-- Theme JS -->
        <script src="<?php echo e(asset('front/assets/js/theme.min.js')); ?>"></script>
    </body>
</html><?php /**PATH F:\booksasa\resources\views/layouts/front/design.blade.php ENDPATH**/ ?>