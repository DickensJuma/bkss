
<?php $__env->startSection('content'); ?>
<script type="text/javascript">
<?php if(session('alert')): ?>
$(document).ready(function () {
    Swal.fire(
        "Good job!",    
    "<?php echo e(session('alert')); ?>",
    "success");
    
});
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Work\booksasa\resources\views/property/policy/add.blade.php ENDPATH**/ ?>