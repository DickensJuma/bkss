

<?php $__env->startSection('content'); ?>
<div class='container'>
    <div class="card">
        <div class="card-header">
            <h5><?php echo e($hotel->name); ?> <a href=""><i class="far fa-heart"></i></a>
                <a href=""><i class="fas fa-share-alt"></i></a>
            <a href="" class="btn btn-primary btn-md">Reserve</a></h5>
            <span class="text-warning" data-toggle="tooltip" data-placement="left" title="This star rating is provided to Book sasa by the property and is usually determined by an official hotel rating organization or another third party.">
                <?php for($star =0 ; $star < $hotel->rating ; $star++): ?>
                &#9734;
                <?php endfor; ?>
            </span>
            <i class="fas fa-thumbs-up text-warning" data-toggle="tooltip" data-placement="left" title="This is a Preferred Partner property. It's committed to giving guests positive experiences with its excellent service and great value. This property might pay Book sasa a little more to be in this Program"></i>
            <i class="fas fa-map-pin" data-toggle="tooltip" data-placement="left" title="After booking, all of the property’s details, including telephone and address, are sent to you as part of your booking confirmation and your account." ><?php echo e($hotel->address2); ?></i>
        </div>
        <div class="card-body">
            <div class="portfolio-area">
                <?php $__currentLoopData = $images->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key===0): ?>
                    <div class="col-md-4">
                        <div>
                            <span class="image-block block2">
                            <a class="image-zoom" href="<?php echo e(asset('uploads/property/large/'.$item->path)); ?>" rel="prettyPhoto[gallery]">							
                                    <img src="<?php echo e(asset('uploads/property/small/'.$item->path)); ?>" class="img-responsive" alt="CEC Gallery"></a>
                        </span>
                        </div>
                    </div>                        
                    <?php else: ?>
                    <div class="col-md-3">
                        <div>
                            <span class="image-block block2">
                            <a class="image-zoom" href="<?php echo e(asset('uploads/property/large/'.$item->path)); ?>" rel="prettyPhoto[gallery]">							
                                    <img src="<?php echo e(asset('uploads/property/small/'.$item->path)); ?>" class="img-responsive" alt="CEC Gallery"></a>
                        </span>
                        </div>
                    </div>
                        
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <table class="table table-striped">
                <thead class="bg-success">
                    <th>Room Type</th>
                    <th>Sleeps</th>
                    <th>Price For<?php echo e($totalstay); ?> <?php echo e(Str::plural('day',$totalstay)); ?></th>
                    <th>Your Choices</th>
                    <th>Select Rooms</th>
                    <th>Reserve?</th>
                </thead>
                <?php echo $hotel_data; ?>
            </table>
        </div>
        
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Work\booksasa\resources\views/room/view.blade.php ENDPATH**/ ?>