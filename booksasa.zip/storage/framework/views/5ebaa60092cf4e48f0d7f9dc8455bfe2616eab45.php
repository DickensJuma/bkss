

<?php $__env->startSection('content'); ?>
<div class='container'>

<?php echo $hotel_data; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MASENO\Music\flash\Zulu\booksasa\resources\views/room/view.blade.php ENDPATH**/ ?>