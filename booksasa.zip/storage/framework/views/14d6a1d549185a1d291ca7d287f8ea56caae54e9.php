<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      <Strong>Designed and developed By: <a href="https://otemainc.com">Otema Technologies</a></Strong>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo e(now()->year); ?> <a href="https://booksasa.com">Book sasa</a>.</strong> All rights reserved.
  </footer><?php /**PATH F:\Work\booksasa\resources\views/layouts/common/footer.blade.php ENDPATH**/ ?>