

<?php $__env->startSection('content'); ?>
    <h2 class="text-primry">Work in Progress!!Be patient</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Zulu\booksasa\resources\views/property/home/new.blade.php ENDPATH**/ ?>