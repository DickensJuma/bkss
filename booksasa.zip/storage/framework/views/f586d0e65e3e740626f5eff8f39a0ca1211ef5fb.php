
<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Work\booksasa\resources\views/property/generalinfo.blade.php ENDPATH**/ ?>